const license = `
-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

authcode?$version=1.0.0&$releasedAt=1614733191928&$validBeginAt=1614733191928&$validEndAt=32503593600000&$validDuration=30888860408072&$deviceTypes=voerka_server&$devices=&$activationCode=X1MW2585EH&$accountNumbers=-1&$deviceNumbers=50&$useTimes=-1
-----BEGIN PGP SIGNATURE-----
Version: OpenPGP.js v4.10.8
Comment: https://openpgpjs.org

wsFzBAEBCAAGBQJgPt+dACEJEHgFSa5yTtj9FiEESSXs/mcxnNiBbBzOeAVJ
rnJO2P1j4BAAw9cgkXLY4xz0AJzWxK/ddlauOpLWMysqFnyTX9dUH8CQ73cV
xFt3vBuqXGBG0L4jAJR7g/X8rIpWYUH1sDMZq2IB1TBPkuSEPPMPh+gqgWC/
fBimpa6fKoAgAVgQD9W/rlsAvuntYOW8U90VeUb2iQv7y5DpgHxovTSI3BZv
pFMaWVmVzUOf9Ubcl3kDyfpySnra2sLN+vRypndEoYQGiIKN4RTHuUIHiNAY
DjXwd22n63OR/bu4jYh+Ag0/jPkNJqCJJR326nJnaz+BXJIKuIf0LY1JSG+u
ndP+f9Nc107+56yaRrv3wiMDI/UsL7Jm/AqOj9ENtP2wkJYMMepAVj9QKBPq
AisBSr4Fq+thymZtqAKpWhq2L0I/uh1lNWDsgswTK5c2s1x7PHeGWF8XpWq4
uaxVagE6ybFEOD5gTD246UtqzYLDezontrp239MOyQ9mwY9HJzsHDjVY0Zr8
aKu97sTaChNDgd4tXMsR/u00IBWxDJ2dtpsLClSVXETsJxec3TZX/P+Z6G0L
ypLnLBAcRHTplGtICP+3BdtgFQD9fa6jrt9N6l6Inqiv/zd77is2Sppd6Pps
jzcTvIKB+BzCIVj7kX17t/9WZgTzYIfooDwXvj5XzEmM9lolUOi4yox+gP/U
w/++bGWmCpRxMjkpCGvL4F0a5aiefcy6MzQ=
=nxl8
-----END PGP SIGNATURE-----
`

module.exports = license
